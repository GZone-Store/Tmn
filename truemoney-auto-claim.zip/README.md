# TrueMoney Auto Claim

ระบบรับซองทรูมันนี่อัตโนมัติ โดยใส่ลิงก์ซองทรูมันนี่และระบบจะรับให้พร้อมตรวจสอบสถานะ (ใช้ไปแล้ว, หมดอายุ, สำเร็จ)

## วิธีใช้งาน

1. ติดตั้ง Python และ Chrome + ChromeDriver
2. ติดตั้งไลบรารี:
   ```
   pip install -r requirements.txt
   ```
3. รันโปรเจกต์:
   ```
   python app.py
   ```
4. เปิดเบราว์เซอร์: [http://localhost:5000](http://localhost:5000)
